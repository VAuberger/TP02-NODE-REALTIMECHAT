import { randomUUID } from 'crypto'
import { format } from 'date-fns'

/**
 * @typedef {Object} Message
 * @property {string} id - an uuid
 * @property {string} pseudo - sender pseudo
 * @property {string} body - body of the message
 */

/** @type { Message[] } */
const messages = []

/**
 * @param {string} pseudo
 * @param {string} body
 */
function handleNewMessage(pseudo, body) {
  const date_envoie = format(new Date(), 'Sent at')
  const message = {
    id: randomUUID(),
    pseudo:pseudo,
    body:body,
    date: date_envoie.toString(),
  }
  messages.push(message)
  return message
}

/**
 * @type { import('fastify').FastifyPluginCallback }
 */
export async function chatRoutes(app) {
  /**
   * @param {{ type: string, payload: object }} data
   */
  function broadcast(data) {
    console.log(
      app.websocketServer.clients.forEach((client) => {
        client.send(JSON.stringify(data))
      }),
    )
  }

  app.get('/', { websocket: true }, (connection, req) => {
    connection.socket.on('message', (message) => {
      const data = JSON.parse(message.toString('utf-8'))
      if (data.pseudo.length > 20 || data.body.length > 2000) {
        connection.socket.send(
          JSON.stringify({type : 'ERROR', payload : 'Jai mis 20 en pseudo et 2000 en text quand même chacal'})
        )
        return
      }
      broadcast({
        type: 'NEW_MESSAGE',
        payload: handleNewMessage(data.pseudo, data.body),
      })
    })
  })

  app.get('/history', (request, reply) => {
    reply.send(messages.slice(-30))
  })
}
